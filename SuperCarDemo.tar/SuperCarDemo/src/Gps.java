public class Gps {
    public Gps() {
    }
    
    public void turnOnGps(){
        System.out.println("Gps is starting .....");
    }
}
