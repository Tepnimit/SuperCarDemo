import java.io.IOException;

public class SuperCarDemo {
    
//    private ServerSocket serverSocket;
    public SuperCarDemo() {
        System.out.println("Hey SuperCarDemo class");
//    serverSocket = new ServerSocket(port);
//    serverSocket.setSoTimeout(50000);
//            
//    while(true){
//        System.out.println("Waiting for client on port " + serverSocket.getLocalPort() + ".....");
//        Socket server = serverSocket.accept();
//        System.out.println("Server Connected");
//        
//    }
    }

    public static void main(String[] args) throws IOException {
    SuperCarOption superCarOption = new SuperCarOption();   // Basic creating an Object
//    superCarOption.supercar.();
    
    }
}
