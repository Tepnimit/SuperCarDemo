public  class Transmission {
    private char shiftgear = 'P'; //Initial
    
    public char getShiftGear(){
        return shiftgear;
    }
    public char setShiftGear(char newShiftGear){
        return shiftgear = newShiftGear;
    }
}