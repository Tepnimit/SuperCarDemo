public interface MovableInt { //All the methods of Interface need to be defined in the class
    public int startEngine();
    public void stopEngine();
    public void increaseSpeed();
    public void decreaseSpeed();
    public void stopVehicle();
}
